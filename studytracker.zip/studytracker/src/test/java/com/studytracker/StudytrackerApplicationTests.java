package com.studytracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudytrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
